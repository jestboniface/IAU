-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 26, 2018 at 06:18 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `india`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('PUBLISHED','DRAFT') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PUBLISHED',
  `date` date NOT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `category_id`, `title`, `slug`, `content`, `image`, `status`, `date`, `featured`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 2, 'Sport for 69th celebration', 'sport-for-69th-celebration', '<p><strong>INDIA INDEPENDENCE GALA.</strong> After 16 days of sweating out for glory on courts and gymnasiums, the Indian Community in Uganda wrapped up their celebrations of marking their 69th anniversary with a mega musical fete at <em>Lugogo Cricket Oval</em> on September 6. The trio of Shankar, Eshaan and Loy were the biggest act of the night and the full house joyfully sang along to most of the tracks.</p>\r\n\r\n<p>The world over celebrated India&rsquo;s 69th Independence Anniversary last month. And the Indian community in Uganda, too, got in on the act by commemorating their liberation day with a 16-day sports gala that climaxed on August 16 and attracted 621 participants.<br />\r\n<em>Held at Kampala Parents School, Kampala Club and MK Badminton Academy</em>, almost each member of the Indian Community took part in one of the sports including volleyball, pool table, chess, table tennis, cricket and badminton.</p>\r\n\r\n<p>The tournament that was graced by the Indian High commissioner to Uganda Dr Ramesh Chandra and Indian Association Chairman Dave Chirag, who presented trophies and medals to the winners, and also hailed the spirit exhibited by the members. There were some outstanding performances in the badminton category particularly where 11-year-old Arshath Mohamed won the Under 13 and Under 15 titles as well as 10-year-old Fadhila Samika, who finish unrivaled in the girls Under 15 girls category.</p>\r\n\r\n<p>There was also a chance for the elderly Meerasa Saleem and Mohideen Ansari, who showed that they still have gifted hands enroute to notching the Veterans and Open categories respectively. Nile Cricket Club all-rounder Sarfraz Chunara was crowned pool table champions after defeating Ali Didar. The thinking game - chess&rsquo; title - was scooped by Sanjay Jaivin, who defeated Gupta Aditya, in the boys category final whereas Shree Kutch Leva Patel Samaj lifted the overall volleyball gong.</p>', 'uploads/news/gala.jpg', 'PUBLISHED', '2015-09-07', 1, '2018-05-26 21:49:51', '2018-05-26 22:15:59', NULL),
(3, 3, 'Uganda: Indians boost Bududa Landslide Victims', 'uganda-indians-boost-bududa-landslide-victims', '<p><strong>THE Indian Association of Uganda (IAU) </strong>has donated food and non-food relief items worth over sh100m to the landslide victims of Bududa.</p>\r\n\r\n<div id=\"content\">\r\n<div id=\"node-350483\">\r\n<p>The items were contributed by individuals, community associations and Indian-owned companies.</p>\r\n\r\n<p>The body also offered an ambulance with doctors and nurses to tackle health challenges through offering free medical assistance to residents for 30 days.</p>\r\n\r\n<p>&quot;Our association has been helping and continues to assist the less fortunate and needy among the local community at large.</p>\r\n\r\n<p>&quot;It has always been our primary goal to be a part of every noble cause and our mission is to help, in whatever way we can,&quot; the association chairman, Naren Mehta, said in a statement. He explained that the Indian community had always considered the social obligation element as an important giveback in response to the existing support rendered by Ugandans.</p>\r\n\r\n<p>&quot;This great country has given us numerous opportunities and the vision of the Indian association is to make it a better place for each and everyone of us,&quot; he said.</p>\r\n\r\n<p>Metha noted that the partnership that exists between India and Uganda had created a conducive atmosphere for investment, giving rise to employment opportunities and enhanced domestic revenues.</p>\r\n\r\n<p>Last December, the IAU offered sh200m to 11 heart patients to undergo surgery at the famous Narayana Hrudalaya, Bangalore, a five-star hospital in India.</p>\r\n\r\n<p>Several individuals and organisations, including Pope Benedict XVI have sympathised with the Bududa victims since the disaster struck early last month.</p>\r\n\r\n<p>Of the landslide that buried three villages and displaced hundreds in bududa district earlier this month.</p>\r\n</div>\r\n</div>', 'uploads/news/landslide.jpg', 'PUBLISHED', '2010-04-12', 1, '2018-05-26 22:12:56', '2018-05-26 22:17:09', NULL),
(4, 3, '20 children set to undergo free heart surgery at India hospital', '20-children-set-to-undergo-free-heart-surgery-at-india-hospital', '<p>&ldquo;We sponsor 10 heart surgeries in India every year. We also run an education scholarship, where we sponsor 100 students in vocational institutes every year,&rdquo; says Dave Chirag, the association&rsquo;s chairman.</p>\r\n\r\n<div itemprop=\"articleBody\">\r\n<div>\r\n<p><strong>Kampala</strong></p>\r\n</div>\r\n\r\n<div>\r\n<p>Twenty children between two and fourteen years will today leave for Bangalore, India where they will undergo heart operation. The children, whose medical treatment will be funded by the Indian Association of Uganda, will undergo the operation at the Narayan Hrudalaya Hospital.</p>\r\n</div>\r\n\r\n<div>\r\n<p>Dr. Prakash Patel, a doctor with the Indian Association of Uganda, said most of the children are suffering from Mitral stenosis, a disorder in which the valves of the heart have an obstruction to open fully to allow enough blood to enter.</p>\r\n</div>\r\n\r\n<div>\r\n<p>&ldquo;This condition can only be corrected surgically, and for the past four years, we have had about 25 Ugandan children operated on with the same condition and they have recovered successively,&rdquo; Dr Patel told journalists in Kampala yesterday.</p>\r\n</div>\r\n\r\n<div>\r\n<p>Speaking to Daily Monitor, Ms Faith Katushabe, mother of two-year-old Precious Arinaitwe, one of the beneficiaries, said her daughter was diagnosed with three holes in her heart last year from the Uganda Heart Institute.</p>\r\n</div>\r\n\r\n<div>\r\n<p>She had been getting the available free medication at the institute but did not have money to undergo an operation. &ldquo;We did not have the Shs15 million needed. So we kept getting the medication as my daughter&rsquo;s condition worsened by the day,&rdquo; Ms Katushabe said, adding, &ldquo;But now I&rsquo;m glad she is going to be operated on free of charge in one of the best hospitals in the world.&rdquo;</p>\r\n</div>\r\n\r\n<div>\r\n<p>The heart operation project initiated by Narendra Vadera, a Ugandan of Indian origin, has been running for almost a decade and sponsors 10 needy children every year. However, parents and caretakers for the patients have to pay for their air tickets which many like Ms Katushabe still have difficulty doing.</p>\r\n</div>\r\n\r\n<div>\r\n<p>Mr Rajesh Chaplot, the president of the India Association of Uganda, said about $8000 (Shs20 million) will be paid for each patient and the care taker. This sponsorship is a gesture shown by Ugandans of Indian origin as a commemoration to mark Uganda&rsquo;s 50 years of independence. This is in addition to a recent mass blood donation drive in which 970 units was collected.</p>\r\n</div>\r\n\r\n<div>\r\n<p>When asked why the operations could not be done in the country, Mr Rajesh said: &ldquo;It is still expensive for us to transport the patients to India but we are working out a system to see if the subsequent surgeries will be done from Mulago Hospital instead of flying them all the way to India.&rdquo; A similar heart surgery would cost between $1000-1500 at the Uganda Heart Institute.&nbsp;</p>\r\n</div>\r\n</div>\r\n\r\n<p>&nbsp;</p>', 'uploads/news/news005px.jpg', 'PUBLISHED', '2012-10-16', 1, '2018-05-26 22:34:08', '2018-05-26 22:35:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `article_tag`
--

CREATE TABLE `article_tag` (
  `id` int(10) UNSIGNED NOT NULL,
  `article_id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `article_tag`
--

INSERT INTO `article_tag` (`id`, `article_id`, `tag_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 2, 1, NULL, NULL, NULL),
(2, 2, 2, NULL, NULL, NULL),
(3, 3, 2, NULL, NULL, NULL),
(4, 3, 3, NULL, NULL, NULL),
(5, 3, 4, NULL, NULL, NULL),
(6, 4, 2, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(11) DEFAULT '0',
  `lft` int(10) UNSIGNED DEFAULT NULL,
  `rgt` int(10) UNSIGNED DEFAULT NULL,
  `depth` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `lft`, `rgt`, `depth`, `name`, `slug`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, NULL, NULL, NULL, NULL, 'SPORTS', 'sports', '2018-05-26 21:57:54', '2018-05-26 21:57:54', NULL),
(3, NULL, NULL, NULL, NULL, 'Charity', 'charity', '2018-05-26 22:13:46', '2018-05-26 22:13:46', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `classifieds`
--

CREATE TABLE `classifieds` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `classifieds`
--

INSERT INTO `classifieds` (`id`, `category_id`, `title`, `image`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, 'hello', 'uploads/slides/banner1.png', 'hello', '<p>some</p>', '2018-05-08 05:51:51', '2018-05-08 05:51:51');

-- --------------------------------------------------------

--
-- Table structure for table `classifieds_categories`
--

CREATE TABLE `classifieds_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `classifieds_categories`
--

INSERT INTO `classifieds_categories` (`id`, `title`, `image`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'shopping', 'uploads/cats/shopping.jpg', 'shopping', '2018-05-08 05:51:24', '2018-05-09 11:09:42'),
(2, 'dinning', 'uploads/cats/dining.jpeg', 'dinning', '2018-05-09 11:10:47', '2018-05-09 11:10:47'),
(3, 'travel', 'uploads/cats/travel.jpeg', 'travel', '2018-05-09 11:11:57', '2018-05-09 11:11:57'),
(4, 'movies', 'uploads/cats/movies.jpeg', 'movies', '2018-05-09 11:12:49', '2018-05-09 11:12:49'),
(5, 'education', 'uploads/cats/education.jpeg', 'education', '2018-05-09 11:14:06', '2018-05-09 11:14:06');

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`id`, `name`, `phone_number`, `email`, `created_at`, `updated_at`) VALUES
(1, 'mugula', '0758281012', 'mugieabbeym@gmail.com', '2018-03-05 03:38:42', '2018-03-05 03:38:42'),
(2, 'linda', '0758281012', 'mugieabbey@gmail.com', '2018-03-05 03:43:53', '2018-03-05 03:43:53'),
(3, 'mafia', '0758281012', '0775017559', '2018-03-05 03:45:18', '2018-03-05 03:45:18'),
(4, 'mugula', '0703921620', 'mugieabbey@gmail.com', '2018-03-05 03:46:40', '2018-03-05 03:46:40'),
(5, 'drake', '0758281012', 'mafa@nezdiro.org', '2018-03-05 03:48:54', '2018-03-05 03:48:54');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `venue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `image`, `venue`, `date`, `description`, `slug`, `created_at`, `updated_at`) VALUES
(3, 'Free Medical Camp - Tororo District', 'uploads/Evens/unnamed.png', 'Tororo District  St. Anthony’s Hospital', '2018-05-15', 'Consultation (General & Dental, Free Medicines, Lab Testing & X-rays\r\nNo. of Patient Treated : 7000 (Young, Old & Children)', 'free-medical-camp', '2018-05-26 22:57:26', '2018-05-26 23:00:46'),
(4, 'IAU & Indo Africa Charitable Society', 'uploads/Evens/northern.png', 'Kamuli District & Lira District at Lacor Hospital', '2016-08-01', 'In Collaboration with Indo Africa Charitable Society\r\nAugust 2016 & September 2017 at Kamuli District & Lira District at Lacor Hospital .No. of Patients Treated     :   Over 25,000', 'iau-indo-africa-charitable-society', '2018-05-26 23:04:43', '2018-05-26 23:04:43'),
(5, 'Dental outreach in collaboration with H.E the Vice President of Uganda', 'uploads/Evens/image (4).png', 'Bukoto Central Masaka District', '2018-05-01', 'Dental outreach in collaboration with H.E the Vice President of Uganda\r\nSeptember 2017 at Constituency of Bukoto Central Masaka District\r\nDental Services. No. of Patients treated           :  Over 1000', 'dental-outreach-in-collaboration-with-h-e-the-vice-president-of-uganda', '2018-05-26 23:08:29', '2018-05-26 23:08:29'),
(6, 'IAU & UGANDA REVENUE AUTHORITY', 'uploads/Evens/image (6).png', 'Kampala District at Kololo Airstrip', '2018-05-27', 'In Partnership with UGANDA REVENUE AUTHORITY  at the 13th Taxpayers Appreciation Week\r\n27th to 29th September 2017  at Kampala District at Kololo Airstrip\r\nEye Check up by ASG Eye Hospital, Dental services by Bhandari Dental Care & General Health Check up by UMC Victoria Hospital.\r\nNo. of Patients treated      :    Over 2,200', 'iau-uganda-revenue-authority', '2018-05-26 23:11:10', '2018-05-26 23:11:10'),
(7, 'Mulago Free medical camp', 'uploads/Evens/image (8).png', 'Mulago Hospital, Kampala, Kampala, Uganda', '2018-05-01', 'Extended Support for the camp organized by Narayan Seva Sansthan in conjunction with Ministry of Health & Mulago Hospital.\r\nMarch & April 2017  at Kampala District at Mulago Hospital\r\nFree medical camp to offer Artificial Limbs and   Orthopedic Services\r\nNo. of Patients treated      :    Over 2,000', 'mulago-free-medical-camp', '2018-05-26 23:13:27', '2018-05-26 23:13:27'),
(8, 'Republic Day Medical Camp with TMMK Uganda', 'uploads/Evens/image (4).png', 'Indian Association Uganda', '2018-08-15', 'Republic Day Medical Camp with TMMK Uganda\r\n15th August 2017 at Indian Association Uganda\r\nNo. of Patients treated      :    Over 300 Orphans', 'republic-day-medical-camp-with-tmmk-uganda', '2018-05-26 23:14:41', '2018-05-26 23:14:41');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `image`, `description`, `created_at`, `updated_at`) VALUES
(1, 'image 1', 'uploads/donation.jpeg', NULL, '2018-05-09 09:59:10', '2018-05-09 09:59:10'),
(2, 'some title', 'uploads/schoolarship.jpg', NULL, '2018-05-09 10:01:23', '2018-05-09 10:01:23'),
(3, 'some title', 'uploads/medical.jpeg', NULL, '2018-05-09 10:01:52', '2018-05-09 10:01:52');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `package` text COLLATE utf8mb4_unicode_ci,
  `company` text COLLATE utf8mb4_unicode_ci,
  `nationality` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page_id` int(10) UNSIGNED DEFAULT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `lft` int(10) UNSIGNED DEFAULT NULL,
  `rgt` int(10) UNSIGNED DEFAULT NULL,
  `depth` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `phone_number`, `subject`, `message`, `created_at`, `updated_at`) VALUES
(8, 'Hackshade', 'team@pro-interns.com', '0752502090', NULL, 'hello', '2018-03-11 20:51:32', '2018-03-11 20:51:32'),
(9, 'abbey', 'mugieabbeym@gmail.com', '758281012', NULL, 'gggg', '2018-03-12 12:00:11', '2018-03-12 12:00:11'),
(10, 'mugula', 'mugieabbeym@gmail.com', '0752502090', NULL, 'hehehehe', '2018-03-12 12:04:44', '2018-03-12 12:04:44'),
(11, 'Abbey', 'mugulaabbey@gmail.com', NULL, 'hello', 'hello', '2018-05-08 08:17:05', '2018-05-08 08:17:05'),
(12, 'Abbey', 'mugulaabbey@gmail.com', NULL, 'hello', 'hello', '2018-05-08 08:18:00', '2018-05-08 08:18:00'),
(13, 'abbey', 'mugulaabbey@gmail.com', NULL, 'maron', 'sfdfdfd', '2018-05-08 08:18:19', '2018-05-08 08:18:19'),
(14, 'abbey', 'mugulaabbey@gmail.com', NULL, 'maron', 'sfdfdfd', '2018-05-08 08:18:45', '2018-05-08 08:18:45'),
(15, 'Mugula Abbey', 'mugulaabbey@gmail.com', NULL, 'jjj', 'he', '2018-05-08 08:36:06', '2018-05-08 08:36:06'),
(16, NULL, NULL, NULL, NULL, NULL, '2018-05-08 08:40:32', '2018-05-08 08:40:32');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2015_08_04_130507_create_article_tag_table', 1),
(4, '2015_08_04_130520_create_articles_table', 1),
(5, '2015_08_04_130551_create_categories_table', 1),
(6, '2015_08_04_131614_create_settings_table', 1),
(7, '2015_08_04_131626_create_tags_table', 1),
(8, '2016_05_05_115641_create_menu_items_table', 1),
(9, '2016_05_25_121918_create_pages_table', 1),
(10, '2016_07_24_060017_add_slug_to_categories_table', 1),
(11, '2016_07_24_060101_add_slug_to_tags_table', 1),
(12, '2017_04_10_195926_change_extras_to_longtext', 1),
(13, '2018_02_13_084110_create_messages', 1),
(14, '2018_02_13_092153_create_sliders', 1),
(15, '2018_03_01_115002_create_events', 2),
(16, '2018_03_01_115031_create_programs', 2),
(17, '2018_03_05_061518_create_donate', 3),
(18, '2018_03_06_220606_create_team', 4),
(32, '2018_03_11_213239_create_testimonials', 6),
(33, '2018_03_17_065412_create_gallery', 6),
(34, '2018_05_08_060138_create_classifieds_category_table', 6),
(35, '2018_05_08_074139_create_partners_table', 6),
(36, '2018_05_08_075642_create_classifieds_table', 6),
(37, '2018_03_11_201308_create_member', 7),
(38, '2018_05_23_150841_create_regional_table', 8);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `extras` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `template`, `name`, `title`, `slug`, `content`, `extras`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'about_us', 'About us page', 'About us', 'about-us', '<p>The Indian Association of Uganda is the apex body for 27,000 Indians/ persons of Indian origin living in Uganda and 46 community based associations. Established 90 years ago in 1922, it&rsquo;s a charitable non-profit making body, registered NGO having its own constitution and incorporated under the trustees Incorporation Act (Cap. 165 of the Laws of Uganda), and is strongly geared towards promoting Social, Educational, Economic &amp; cultural welfare of the people and residents of Uganda.</p>', '{\"image\":\"uploads\\/about.png\"}', '2018-03-01 08:32:50', '2018-05-19 09:59:17', NULL),
(2, 'events', 'Events page', 'events', 'events', NULL, NULL, '2018-03-01 08:33:08', '2018-03-01 08:33:08', NULL),
(3, 'contact', 'Contact page', 'contact us', 'contact-us', NULL, NULL, '2018-03-01 08:33:23', '2018-03-01 08:33:23', NULL),
(4, 'programs', 'Programs page', 'programs', 'community', NULL, NULL, '2018-03-01 08:33:49', '2018-05-08 12:07:27', NULL),
(5, 'membership', 'Membership page', 'membership registeration', 'membership-registration', NULL, NULL, '2018-03-11 15:28:21', '2018-05-08 10:06:21', NULL),
(6, 'gallery', 'Gallery page', 'gallery', 'gallery', NULL, NULL, '2018-03-17 05:27:21', '2018-03-17 05:27:21', NULL),
(8, 'blog', 'news', 'news', 'news', NULL, NULL, '2018-05-19 08:44:33', '2018-05-19 08:44:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE `partners` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `partners`
--

INSERT INTO `partners` (`id`, `name`, `image`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(1, 'partner 1', 'uploads/partners/ugredLogo.png', 'partner-1', NULL, '2018-05-09 07:15:01', '2018-05-09 07:15:01'),
(2, 'partner 2', 'uploads/partners/LN1fuXQ.jpg', 'partner-2', NULL, '2018-05-09 07:15:29', '2018-05-09 07:15:29'),
(3, 'partner 3', 'uploads/partners/download.jpg', 'partner-3', NULL, '2018-05-09 07:15:57', '2018-05-09 07:15:57'),
(4, 'partner 4', 'uploads/partners/make-in-india-L.jpg', 'partner-4', NULL, '2018-05-09 07:16:15', '2018-05-09 07:16:15'),
(5, 'partner 5', 'uploads/partners/cropped-incredibleindia-logo-1.png', 'partner-5', NULL, '2018-05-09 07:16:39', '2018-05-09 07:16:39'),
(6, 'partner 6', 'uploads/partners/Digital_India_empower_youth.jpg', 'partner-6', NULL, '2018-05-09 07:52:38', '2018-05-09 07:52:38');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE `programs` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `pics` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `programs`
--

INSERT INTO `programs` (`id`, `title`, `image`, `date`, `pics`, `description`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Medical camps', 'uploads/medical.jpeg', '2017-11-05', '[\"others\\/dac27389264751234f0d7eee9291eb5d.png\"]', '<p>Through various collaborations national and International, we organize and manage free medical camps to bring services near to the people and also help the community to freely address and open up their medical concerns.</p>\r\n\r\n<p>The service was part of the contributions by the Indian community to Support the least advantaged communities who have health complication but can&rsquo;t afford to meet treatment cost. The initiative was taken to enhance our commitments and fulfill our Social responsibility</p>', 'medical-camps', '2018-03-15 06:52:08', '2018-05-19 11:42:55'),
(2, 'Blood donation', 'uploads/blood2.png', '2018-03-01', '[]', '<p class=\"grey-text\" style=\"font-size: 120% \">In 2012, Uganda celebrated 50 years of independence and in respect to that, Indian association of Uganda initiated and pledged to support Uganda Blood Bank/ Uganda Red Cross through corporate and communities owned/managed by Indians in Uganda.</p>\r\n\r\n<p class=\"grey-text\" style=\"font-size: 120% \">The Major objective of this drive is to generate awareness of Blood Donation, its significance in saving lives and prepare a directory of Voluntary Blood Donors with their blood group.</p>\r\n\r\n<p class=\"grey-text\" style=\"font-size: 120% \">There is a serious lack of awareness about the need of blood donation in Uganda. At present there is acute shortage of blood in all blood bank/health centers throughout Uganda. Hence this is a great opportunity for us as the Indian community to come forward to help this drive. So far we have organized over 150 drives and managed to collect over 15,000 units of blood.</p>', 'blood-donation', '2018-03-15 06:53:43', '2018-05-19 11:41:05'),
(3, 'Scholarship', 'uploads/schoolarship.jpg', '2018-02-05', '[]', '<p class=\"grey-text\" style=\"font-size: 120% \">Since 2012, Indian Association has been providing scholarships covering tuition fees to needy but talented Ugandan students. So far over 150 students have benefited from the program.</p>', 'scholarship-program', '2018-03-15 06:54:48', '2018-05-19 11:41:21'),
(4, 'Heart Surgery', 'uploads/heart_surgery.png', '2017-11-26', '[]', '<p class=\"grey-text\" style=\"font-size: 120% \">Under the Heart Surgery Project courtesy Image India Project, we have sponsored Ugandan heart patients, age below 14 years for surgery at Narayana Hrudayalaya Hospital Bangalore. IAU has successfully sponsored 87 Heart Surgeries for less fourtunate Ugandan Children.</p>\r\n\r\n<p class=\"grey-text\" style=\"font-size: 120% \">They are all healthy and happy enjoying the normal life. Our Members accompanies the children with their guardians to Narayana Hospital and makes sure of their comfortable stay in India and travels back with children when they are fit to travel.</p>\r\n\r\n<p class=\"grey-text\" style=\"font-size: 120% \">The IAU bears all costs from Kampala to Narayana Hrudayalaya and back home and ensuring that each patient has enough medicines for the next 2/3 months post surgery. In short the IAU provides door to door service to Ugandan children. Usual stay for the patient with guardian is 45 days at Narayana Hrudayalaya Bangalore.</p>', 'heart-surgery', '2018-03-15 06:55:46', '2018-05-19 11:41:50');

-- --------------------------------------------------------

--
-- Table structure for table `regional`
--

CREATE TABLE `regional` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `regional`
--

INSERT INTO `regional` (`id`, `title`, `team`, `slug`, `created_at`, `updated_at`) VALUES
(3, 'Office of High Commission', '[{\"name\":\"H.E Ravi Shankar\",\"designation\":\"High Commissioner\",\"email\":\"hc.kampala@mea.gov.in\"},{\"name\":\"Mr. Pankaj Kumar Singhal\",\"designation\":\"Seco Secretary (POL  & HOC\",\"phone\":\"0759207100\",\"email\":\"hoc.kampala@mea.gov.in\"},{\"name\":\"Mr. Saurabh Anand\",\"designation\":\"ASO (Consular )\",\"phone\":\"0759207102\",\"email\":\"consular@hcikampala.co.ug\"},{\"designation\":\"Second Secretary PPS to HC\",\"name\":\"Mr. Bharat Bhushan\",\"phone\":\"0759207101\",\"email\":\"admin@hcikampala.co.ug\"},{\"name\":\"Mr. Indrepreet Singh\",\"designation\":\"ASO (Admin)\",\"phone\":\"0759207143\",\"email\":\"accounts@hcikampala.co.ug\"},{\"name\":\"Mr. D.Das\",\"designation\":\"ASO\",\"email\":\"pshc@hcikampala.co.ug hc.kampala@mea.gov.in\",\"phone\":\"0756635897\"},{\"name\":\"Mr. K Rajesh Kunnumal\",\"designation\":\"AP & WO\",\"phone\":\"0759207137\",\"email\":\"Consular2@hcikampala.co.ug\"},{\"email\":\"education.kampala@mea.gov.in\",\"phone\":\"0759207405\",\"name\":\"Mr. Kheema Nand Pathak\",\"designation\":\"Education & Cultural Rel. Off.\"},{\"designation\":\"Security Assistant\",\"name\":\"Mr. Nirmal Kumar Subba\",\"phone\":\"0705068131\"},{\"designation\":\"Security Assistant\",\"name\":\"Mr. Pravasa Ranjan Tripathy\",\"phone\":\"0755772535\"},{\"designation\":\"Security Assistant\",\"name\":\"Mr. Mohan Singh\",\"phone\":\"0755866775\"},{\"designation\":\"Clerk\",\"name\":\"Mr. Andrew Wamala\",\"phone\":\"0701363475\",\"email\":\"social.kampala@mea.gov.in\"}]', 'office-of-high-commission', '2018-05-25 23:33:26', '2018-05-25 23:55:17'),
(4, 'Indian Association Uganda- Jinja', '[{\"designation\":\"Advisor\",\"name\":\"Mr. Maganbahi Patel\",\"phone\":\"716778813\",\"email\":\"kchackobabu@yahoo.com\"},{\"designation\":\"Advisor\",\"name\":\"Mr. Chacko Babu\",\"phone\":\"772222959\\/712122444\"},{\"designation\":\"Chairman\",\"name\":\"Mr. Raojibhai Patel\",\"phone\":\"752503838\\/712503838\",\"email\":\"welltechjinja@gmail.com\"},{\"designation\":\"Vice Chairman\",\"name\":\"Mr. Harshad Bhai Patel\",\"phone\":\"772491404\"},{\"phone\":\"752798479\",\"designation\":\"Secretary\",\"name\":\"Mr. K.F. Bommanjee\",\"email\":\"bomanjee@kakirasugar.com\"},{\"email\":\"balaji.pokuri@yahoo.com\",\"phone\":\"712999786\",\"designation\":\"Jt. Secretary\",\"name\":\"Mr. P.V.S. Balaji\"},{\"name\":\"Mr. Ripson Kennedy\",\"designation\":\"Treasurer\",\"phone\":\"716778815\"},{\"phone\":\"717565704\\/755565104\",\"name\":\"Mr. Minesh Patel\",\"designation\":\"Jt. Treasurer\"},{\"name\":\"Mr. Kishor Bhai Kotecha\",\"designation\":\"Member\",\"phone\":\"772468575\"},{\"designation\":\"Member\",\"name\":\"Mr. Piyush Bhai Kotecha\",\"phone\":\"754688886\\/712688886\"},{\"designation\":\"Member\",\"name\":\"Mr. Janak Bhai Patel\",\"phone\":\"712550450\"},{\"designation\":\"Member\",\"name\":\"Mr. Prakashbhai Raichura\",\"phone\":\"752507322\\/712507322\"},{\"designation\":\"Member\",\"name\":\"Mr. Anil Bhai Patel\",\"phone\":\"715210580\\/756242448\"}]', 'indian-association-uganda-jinja', '2018-05-26 00:08:06', '2018-05-26 00:08:06'),
(5, 'Andhra Cultural Association', '[{\"name\":\"Mr. B.S Ramesh Babu\",\"designation\":\"Chairman (TTD Trustees)\",\"phone\":\"712230121\",\"email\":\"ramesh@kibokogroup.com\"},{\"name\":\"Mr. Prasad Reddy\",\"designation\":\"Vice Chairman (TTD Trustees)\"},{\"name\":\"Mr. Mohan Rao\",\"designation\":\"General Secretary (TTD Trustees)\",\"phone\":\"772222501\",\"email\":\"gnmro2003@yahoo.co.in\"},{\"designation\":\"Exe. Com. Chairman (TTD Trustees)\",\"phone\":\"\",\"name\":\"Mr. M. Sitaram Reddy\"},{\"designation\":\"Treasurer (TTD Trustees)\",\"name\":\"Mr. Satyanarayana K.V.V\",\"phone\":\"718320777\",\"email\":\"Satya_makss@yahoo.com\"},{\"name\":\"Mr. A. Hanumantha\",\"designation\":\"Exe. Com. Vice Chairman (TTD Trustees)\"},{\"designation\":\"Exe. Com. Gen. Secretary (TTD Trustees)\",\"name\":\"Mr. Ram Mohan\"},{\"name\":\"Mr. Gopal\",\"designation\":\"Trustee\"},{\"name\":\"Mr. D. Venugopal Rao\",\"designation\":\"Trustee\"},{\"name\":\"Mr. Mahesh\",\"designation\":\"Trustee\"},{\"name\":\"Mr. G.G Krishna Reddy\",\"designation\":\"Trustee\"},{\"designation\":\"ACA Advisors\",\"name\":\"Mr. A. Hanumantha Rao\"},{\"designation\":\"ACA Advisors\",\"name\":\"Mr. G.G Krishna Reddy\"},{\"designation\":\"ACA Advisors\",\"name\":\"Mr. A. Venkata Reddy\"},{\"designation\":\"ACA Advisors\",\"name\":\"Mr. B.S Ramesh Babu\"},{\"designation\":\"ACA Advisors\",\"name\":\"Mr. M. Sitaram Reddy\"},{\"designation\":\"Chairman  (ACA)\",\"name\":\"Mr. Mohan Rao\",\"phone\":\"752222501\",\"email\":\"Gnmrao2003@yahoo.co.in\"},{\"name\":\"Mr. Challa Siva Koti Reddy\",\"designation\":\"Vice Chairman (ACA)\",\"phone\":\"712877888\",\"email\":\"aparnasiva22@gmail.com\"},{\"designation\":\"General Secretary (ACA)\",\"name\":\"Mr. P.V N. Kiran\",\"phone\":\"712565030\",\"email\":\"kiran_1044@yahoo.com\"},{\"designation\":\"Joint Secretary (ACA)\",\"name\":\"Mr. D. Satyanarayana\",\"phone\":\"718320777\",\"email\":\"satya_makss@yahoo.com\"},{\"name\":\"Mr. B. Adinarayana\",\"designation\":\"Treasurer (ACA)\"},{\"designation\":\"Jt. Treasurer (ACA)\",\"name\":\"Mr. M.V Ravi Kishore\",\"phone\":\"712217221\",\"email\":\"ravikishore_mv@yahoo.com\"},{\"designation\":\"Cultural  Secretary (ACA)\"},{\"designation\":\"Committee Member\",\"name\":\"Mr. D. Seshu Bahu\"},{\"designation\":\"Committee Member\",\"name\":\"Mr. Dilip Kumar\"},{\"designation\":\"Committee Member\",\"name\":\"Mr. D. Durga Raju\"},{\"designation\":\"Committee Member\",\"name\":\"Mr. M. Naresh\"},{\"name\":\"Mr. K. Naidu\",\"designation\":\"Committee Member\"},{\"name\":\"Mrs. Kavita Venkat\",\"designation\":\"Committee Member\"}]', 'andhra-cultural-association', '2018-05-26 00:14:20', '2018-05-26 00:47:31'),
(6, 'Aga Khan National Council', '[{\"designation\":\"President\",\"name\":\"Mr. Rai Minaz Pyarali Jamal\",\"phone\":\"711043292\",\"email\":\"minazjamal@yahoo.co.uk\"},{\"designation\":\"Vice President\",\"name\":\"Mr. Naznin Aneez Jaffer\",\"phone\":\"717786678\",\"email\":\"Jaffer.naz@gmail.com\"},{\"name\":\"Mr. Huzur Mukhi Shokat Shabudin Dhrolia\",\"designation\":\"Mukhi Saheb Darkhana\",\"phone\":\"712900786\\/782569029\",\"email\":\"shokatdhrolia@yahoo.com\"},{\"designation\":\"Chairperson ITREB\",\"name\":\"Mr. Alijah Saheba Arzina Riyaz Kurji\",\"phone\":\"756708534\",\"email\":\"arzinak@yahoo.com\"},{\"designation\":\"Chairperson NCAB\",\"name\":\"Mr. Yasmin Allibhai Popat\",\"phone\":\"752715786\",\"email\":\"Yasmin.allibhai@gmail.com\"},{\"name\":\"Mr. Azim  Haiderali Kassam\",\"designation\":\"Chairman GRB\",\"phone\":\"785955624\",\"email\":\"Azim.kassam@hotmail.com\"},{\"designation\":\"Chairperson AKEB\",\"name\":\"Mr. Ameena Parvez Lalani\",\"phone\":\"757861109\",\"email\":\"amilalani@gmail.com\"},{\"designation\":\"Chairperson AKHB\",\"name\":\"Mr. Gulzar Hirani\",\"phone\":\"751757117\",\"email\":\"Gulzar.hirani@gmail.com\"},{\"designation\":\"Chairperson \\u2013SWB\",\"name\":\"Mr. Amyn Nasiruddin Shamsy\",\"phone\":\"772748946\",\"email\":\"md@qualityuganda.com\"},{\"designation\":\"Chairman- EPB\",\"name\":\"Mr. Amirali Amiruddin Jassani\",\"phone\":\"711500097\\/ 759778866\",\"email\":\"Jasani2@hotmail.com\"},{\"designation\":\"Member \\u2013 Comm. &Pub\",\"name\":\"Mr. Laila Razak Nurani\",\"phone\":\"776126594\",\"email\":\"lailarnurani@gmail.com\"},{\"designation\":\"Member- Legal Matters\",\"name\":\"Mr.Zaheer Amiruddin Nathani\",\"phone\":\"780505555\\/752125555\",\"email\":\"royalzaheer@hotmail.com\"},{\"designation\":\"Member \\u2013 Women Dev.\",\"name\":\"Mr. Farida  Amin  Charania\",\"phone\":\"712752275\\/752752275\",\"email\":\"faridacharania@yahoo.com\"},{\"name\":\"Mr. Asif  Amirali  Patel\",\"designation\":\"Members- Youth & sports\",\"phone\":\"755786543\",\"email\":\"Asifpatel1311@gmail.com\"},{\"designation\":\"Member- outreach\",\"name\":\"Mr. Nadim Kemal Lalani\",\"phone\":\"772786777\",\"email\":\"nadimlalani@hotmail.com\"},{\"designation\":\"Member \\u2013 HRD\",\"name\":\"Mr. Sharmin Anwar Minsariya\",\"phone\":\"758999786\",\"email\":\"Sharmim_am@yahoo.com\"},{\"designation\":\"Member- Crisis Mgt\",\"name\":\"Mr. Rai  Alykhan  Amirali Karmali\",\"phone\":\"772712671\",\"email\":\"karmalialykhan@gmail.com\"},{\"designation\":\"Member- District Jamat\",\"name\":\"Mr. Firoz  Ali Hassanali Ratnani\",\"email\":\"Iap_ratnani@yahoo.com\",\"phone\":\"754669842\\/776669842\"},{},{}]', 'aga-khan-national-council', '2018-05-26 01:47:56', '2018-05-26 01:47:56'),
(7, 'Kerala Samaj', '[{\"designation\":\"Patron\",\"name\":\"Mr. Sasi Nair\",\"phone\":\"757004437\",\"email\":\"vsasinair@gmail.com\"},{\"designation\":\"Chairman\",\"name\":\"Mr. Krishdnas\",\"phone\":\"712576072\\/75376072\",\"email\":\"krishdas009@yahoo.co.in\"},{\"designation\":\"Vice Chairman\",\"name\":\"Mr. Surendra Babu\",\"phone\":\"750429999\",\"email\":\"Spbabu9@gmail.com\"},{\"designation\":\"Secretary\",\"name\":\"Mr. Shine K.S\",\"phone\":\"712944194\",\"email\":\"Shineprem2010@gmail.com\"},{\"designation\":\"t. Secretary\",\"name\":\"Mr. Hareesh Kumar\",\"phone\":\"712731787\",\"email\":\"hariaptech@gmail.com\"},{\"designation\":\"Treasurer\",\"name\":\"Mr. Peeushi Pillai\",\"phone\":\"704654654\",\"email\":\"peeushppillai@gmail.com\"},{\"designation\":\"Jt. Treasurer\",\"name\":\"Mr. Deepu Mathukutty John\",\"phone\":\"712828533\",\"email\":\"mathukutty.here@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr. Sunu AP\",\"phone\":\"783620434\",\"email\":\"sunuap@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr. Mohamed Nizam\",\"phone\":\"757424000\",\"email\":\"nizam@eapsl.com\"},{\"designation\":\"Member\",\"name\":\"Mr. Sunil Kumar\",\"phone\":\"755526276\",\"email\":\"Sunilkmr9495@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr. George Thomas\",\"phone\":\"712593423\",\"email\":\"georgethomas65@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr. Rajeesh  Menon\",\"phone\":\"750774999\",\"email\":\"rm.mangalath@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr.Jikku George\",\"phone\":\"752211030\",\"email\":\"jikkugeorge@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr. Ripson Kennedy\",\"phone\":\"757778815\",\"email\":\"ripsonkennedy@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr. Rajeev Rajan\",\"phone\":\"750351637\",\"email\":\"rjvn2007@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr. Manu Muralidharan\",\"phone\":\"756909662\",\"email\":\"manoos100@gmail.com\"}]', 'kerala-samaj', '2018-05-26 01:52:15', '2018-05-26 01:55:08'),
(8, 'Baps Temple', '[{\"designation\":\"Chairman\",\"name\":\"Mr. Ghanshyambhai P. Patel\",\"phone\":\"711685137\\/772415658\",\"email\":\"magnum.1994@hotmail.com  ghanshyamkasee@gmail.com\"},{\"designation\":\"BOT Trustee\",\"name\":\"Mr. Ramjibhai  K. Swaminarayan\",\"phone\":\"772786108\\/752768671\",\"email\":\"swaminarayan.ramji@yahoo.com\"},{\"designation\":\"BOT Trustee\",\"name\":\"Mr. Navnitray D. Patel (Bhagatakar)\",\"phone\":\"712410617\",\"email\":\"swaminarayan.ramji@yahoo.com\"},{\"designation\":\"BOT Trustee\",\"name\":\"Mr. Babubhai  Patel \\u2013Jinja\",\"phone\":\"754700007\",\"email\":\"bavima@source.co.ug\"},{\"designation\":\"BOT Secretary\",\"name\":\"Mr.  Nareshbhai  Jashbhai  Patel\",\"phone\":\"715740630\\/772455779\",\"email\":\"naresh_ug@yahoo.com  naresh4baps@gmail.com\"},{\"designation\":\"MC. Mandir Coordinator\",\"name\":\"Mr. Nareshbhai  Jashbhai  Patel\",\"phone\":\"715740630\\/772455779\"},{\"designation\":\"CM Comm. Member\",\"name\":\"Mr. Pankajbhai  Bhavsar\",\"phone\":\"755844146\\/701844146\",\"email\":\"pankaj@dembe.co.ug\"},{\"designation\":\"CM Comm. Member\",\"name\":\"Mr. Ajay Kailash Singh\",\"phone\":\"712896406\",\"email\":\"ajaykailash1974@gmail.com\"},{\"designation\":\"CM. Comm. Member\",\"name\":\"Mr. Natverbhai  Patel\",\"phone\":\"755503503\",\"email\":\"natverv@gmail.com\"},{\"designation\":\"CM. Comm. Member\",\"name\":\"Mr. Prasantbhai  Swaminarayan\",\"phone\":\"772791656\\/712964680\",\"email\":\"rabdia@yahoo.co.in\"}]', 'baps-temple', '2018-05-26 02:01:39', '2018-05-26 02:01:39'),
(9, 'Patidar Samaj', '[{\"designation\":\"Chairman\",\"name\":\"Mr. Ranchodbhai G. Patel\",\"phone\":\"752790570\"},{\"designation\":\"Secretary\",\"name\":\"Mr. Kamleshbhai P. Patel\",\"phone\":\"772426003\",\"email\":\"pktjk@yahoo.com\"},{\"designation\":\"Treasurer\",\"name\":\"Mr. Kamleshbhai P. Patel\",\"phone\":\"750577814\"},{\"designation\":\"Member\",\"name\":\"Mr. Narendrabhai J.Patel\",\"phone\":\"703788808\"},{\"designation\":\"Member\",\"name\":\"Mr. Naineshbhai A.Patel\",\"phone\":\"759806401\",\"email\":\"Napatel55@hotmail.com\"},{\"designation\":\"Chairman (2015-16)\",\"name\":\"Mr. Daxesh R. Patel\",\"phone\":\"752111007\"},{\"designation\":\"Vice Chairman (2015-16)\",\"name\":\"Mr. Kiran K. Patel\",\"phone\":\"758458154\"},{\"designation\":\"Secretary (2015-16)\",\"name\":\"Mr. Rajesh Amin\",\"phone\":\"755900710\\/712401003\",\"email\":\"rkamin123us@yahoo.com\"},{\"designation\":\"Ass. Secretary (2015-16)\",\"name\":\"Mr. Minesh M.Patel\",\"phone\":\"754327373\"},{\"designation\":\"Treasurer (2015-16)\",\"name\":\"Mr. Dharmesh C. Patel\",\"phone\":\"772467977\"},{\"designation\":\"Ass. Treasurer (2015-16)\",\"name\":\"Mr. Hitesh S.Patel\",\"phone\":\"772406800\"},{\"designation\":\"Member\",\"name\":\"Mr. Brijesh V.Patel\",\"phone\":\"757868120\"},{\"name\":\"Mr. Bharat B. Patel\",\"designation\":\"Member\",\"phone\":\"759700801\"},{\"name\":\"Mr. Hemant A.Patel\",\"designation\":\"Member\",\"phone\":\"753711704\"},{\"name\":\"Mr. Sunil A. Patel\",\"designation\":\"Member\",\"phone\":\"752344285\"},{\"name\":\"Mr. Tejas G. Patel\",\"designation\":\"Member\",\"phone\":\"750476371\"},{\"name\":\"Mr. Vijay Patel\",\"designation\":\"Member\",\"phone\":\"752459317\\/712459317\",\"email\":\"vijay171967@gmail.com\"},{\"name\":\"Mr. Yogesh M. Patel\",\"designation\":\"Member\",\"phone\":\"755655911\"}]', 'patidar-samaj', '2018-05-26 02:33:50', '2018-05-26 02:33:50'),
(10, 'Indian Women Association – Estd', '[{\"name\":\"Hon Rajni Tailor\",\"designation\":\"Advisory\",\"phone\":\"772736444\\/414230068\",\"email\":\"priamit@priamittyres.com\"},{\"designation\":\"Advisory\",\"name\":\"Mrs. Usha Jog\",\"phone\":\"712891611\",\"email\":\"Crownberger@utlonline.co.ug\"},{\"designation\":\"Chairman (BOT)\",\"name\":\"Mr. Parminder Singh\",\"phone\":\"772666666\",\"email\":\"katongolesmp@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr. Parthsarathi\",\"phone\":\"\"},{\"designation\":\"Member\",\"name\":\"Mrs. Kratika Shah\",\"phone\":\"759361111\",\"email\":\"prathamafrica@yahoo.com\"},{\"designation\":\"Member\",\"name\":\"Mrs. Darshna Kotecha\",\"phone\":\"772706777\"},{\"name\":\"Mrs. Namita Agarwal\",\"designation\":\"Member\",\"phone\":\"752744883\"},{\"name\":\"Mrs. Suman Venkatesh\",\"designation\":\"Chairperson\",\"email\":\"Suman7venkatesh@gmail.com\",\"phone\":\"717321371\\/759614339\"},{\"designation\":\"Vice Chairperson\",\"name\":\"Mrs. Rashmi Nayan Kori\",\"phone\":\"754329510\",\"email\":\"austalopedhicus@gmail.com\"},{\"designation\":\"Secretary\",\"name\":\"Mrs. Hiranmai Jagan\",\"phone\":\"712250272\\/700250272\",\"email\":\"hilanmayee_s@yahoo.com\"},{\"designation\":\"Jt. Secretary\",\"name\":\"Mrs. Falguni Patel\",\"phone\":\"756247575\",\"email\":\"bharatfalguni@yahoo.com\"},{\"designation\":\"Treasurer\",\"name\":\"Mrs. Neala Hudda\",\"phone\":\"753474738\\/702474738\",\"email\":\"h_neala@yahoo.com\"},{\"designation\":\"Jt. Treasurer\",\"name\":\"Mrs. Charu Divecha\",\"phone\":\"755426909\",\"email\":\"divechadd@yahoo.com\"},{\"designation\":\"Member\",\"name\":\"Mrs. Piyali Chowdhury\",\"phone\":\"\"},{\"designation\":\"Member\",\"name\":\"Mrs. Manisha Shah\",\"phone\":\"712233629\",\"email\":\"Manisha_s_shah@yahoo.com\"},{\"designation\":\"Member\",\"phone\":\"752744718\",\"name\":\"Mrs. Aruna Jog\",\"email\":\"aarunaakhilesh@gmail.com\"},{\"designation\":\"Member\",\"phone\":\"\",\"name\":\"Mrs. Shereya Varun\"},{\"designation\":\"Member\",\"name\":\"Mrs. Jagrit Kaur\",\"phone\":\"750537170\"},{\"designation\":\"Member\",\"name\":\"Mrs. Jayshree Patel\"}]', 'indian-women-association-estd', '2018-05-26 02:47:37', '2018-05-26 02:47:37'),
(11, 'Ramgarhia Sikh Sports Club', '[{\"designation\":\"Board of Trustees\",\"name\":\"Mr. Charanjit Singh Bhamra\",\"phone\":\"712859104\"},{\"designation\":\"Board of Trustees\",\"name\":\"Mr. Avtar Singh Marwaha\",\"phone\":\"712458406\"},{\"designation\":\"Board of Trustees\",\"name\":\"Mr. Mohinder Singh Channa\",\"phone\":\"706502470\"},{\"designation\":\"Chairman\",\"name\":\"Mr. Inder Pal Singh Panesar\",\"phone\":\"752756787\",\"email\":\"panconind@hotmail.com\"},{\"designation\":\"Vice Chairman\",\"name\":\"Mr. Narinder Pal Singh Panesar\",\"phone\":\"772472498\",\"email\":\"npspanesar@gmail.com\"},{\"designation\":\"Hon. Secretary\",\"name\":\"Mr. Manpreet Singh\",\"phone\":\"754466609\",\"email\":\"rimpal2001@gmail.com\"},[],[],[],[],{\"designation\":\"Member\",\"name\":\"Mr. Gursharan Singh Marwaha\",\"phone\":\"753412902\",\"email\":\"gulumarwaha2000@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr. Gurdyal Singh Lotey\",\"phone\":\"752777995\",\"email\":\"gs.lotay@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr. Jasdeep Singh Bhamra\",\"phone\":\"758859104\"},{\"designation\":\"Member\",\"name\":\"Mr. Swaran Singh Matharu\",\"phone\":\"755431854\"}]', 'ramgarhia-sikh-sports-club', '2018-05-26 03:37:21', '2018-05-26 14:04:54'),
(12, 'Indian Catholic Committee', '[{\"designation\":\"Chairman\",\"name\":\"Mr. James  Mahimadoss\",\"phone\":\"752965575\",\"email\":\"mahimaidossjames@gmail.com\"},{\"designation\":\"Secretary\",\"name\":\"Mr. Tharun Patnaik\",\"phone\":\"752741373\",\"email\":\"gm@eastafricandistributors.com\"},{\"designation\":\"Treasurer\",\"name\":\"Mr. Albert Benedict\",\"phone\":\"712239275\",\"email\":\"aba\\u00ad\\u00ad_albert@yahoo.com\"},{\"designation\":\"Member\",\"name\":\"Mrs. Tina Ajay\",\"phone\":\"772777776\"},{\"designation\":\"Member\",\"name\":\"Mr. Basil Lobo\",\"phone\":\"772652997\"},{\"designation\":\"Member\",\"name\":\"Mrs. Jasmina Lobo\",\"phone\":\"772652997\"},{\"designation\":\"Member\",\"name\":\"Mr. Jerry Pacheco\",\"phone\":\"774368967\"}]', 'indian-catholic-committee', '2018-05-26 14:08:16', '2018-05-26 14:08:16'),
(13, 'Shree Jain Samaj Uganda', '[{\"designation\":\"Chairman\",\"name\":\"Mr. Devang Shah\",\"phone\":\"752213044\",\"email\":\"devang_b_shah@yahoo.com\"},{\"designation\":\"Vice Chairman\",\"name\":\"Mr. Amul  Shah\",\"phone\":\"711990990\",\"email\":\"amul090960@yahoo.com\"},{\"designation\":\"Hon. Gen. Secretary\",\"name\":\"Mr. Jatin Udani\",\"phone\":\"758122211\\/776812219\",\"email\":\"prismasuppliesltd@yahoo.com\"},{\"designation\":\"Hon. Jt. Secretary\",\"name\":\"Mr. Dakshesh Shah\",\"phone\":\"703600260\",\"email\":\"daksheshjshah@gmail.com\"},{\"designation\":\"Hon. Treasurer\",\"name\":\"Mr. Hiten Shah\",\"phone\":\"772722036\",\"email\":\"hiten3964@gmail.com\"},{\"designation\":\"Hon. Jt. Treasurer\",\"name\":\"Mr. Bhavin Modi\",\"phone\":\"712193259\",\"email\":\"bhavinsmodi@rediffmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr. Mahesh Shah\",\"phone\":\"712534555\",\"email\":\"shahmvs@yahoo.co.in\"},{\"designation\":\"Member\",\"name\":\"Mrs. Manish Saumil Shah\",\"phone\":\"752344449\",\"email\":\"kalpesh@fabricaionsystems.co.ug\"},{\"designation\":\"Member\",\"name\":\"Mrs. Manish Saumil Shah\",\"phone\":\"712233629\",\"email\":\"Manisha_s_shah@yahoo.com\"}]', 'shree-jain-samaj-uganda', '2018-05-26 14:12:39', '2018-05-26 14:12:39'),
(14, 'Maharashtra Mandal Kampala', '[{\"designation\":\"Chairman\",\"name\":\"Mr. Dev Chitale\",\"phone\":\"757744380\",\"email\":\"devdatta.chitale@tatainternational.com\"},{\"designation\":\"Vice Chairman\",\"name\":\"Mr. Girish Diwakar\",\"phone\":\"751521462\",\"email\":\"Girsh.diwakar@gmail.com\"},{\"designation\":\"Secretary\",\"name\":\"Mrs. Bhavna Shendye\",\"phone\":\"759806364\",\"email\":\"Bhavna.shendye@gmail.com\"},{\"designation\":\"Treasurer\",\"name\":\"Mr. Sagar Sawant\",\"phone\":\"759009011\",\"email\":\"Sagarsawant3282@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mrs. Aruna Jog\",\"phone\":\"752744718\",\"email\":\"aarunaakhilesh@gmail.com\"}]', 'maharashtra-mandal-kampala', '2018-05-26 14:17:03', '2018-05-26 14:17:03'),
(15, 'North Indian Cultural Association ( NICA): (2017 – 2019)', '[{\"name\":\"Mr. P.K Sharma\",\"designation\":\"Patron\",\"email\":\"pk@tightsecurity.co.ug\"},{\"name\":\"Mr. Shalendra Kundra\",\"designation\":\"Patron\",\"phone\":\"754777704\"},{\"name\":\"Mr. Naren Mehta\",\"designation\":\"Patron\",\"phone\":\"772750333\",\"email\":\"naren_mehta47@hotmail.com\"},{\"name\":\"Mr. Abhay Agarwal\",\"designation\":\"Patron\",\"email\":\"captain@sciug.com\"},{\"designation\":\"Chairman\",\"name\":\"Mr. Dharmendra  Agarwal\",\"phone\":\"756888123\"},{\"designation\":\"Vice Chairman\",\"name\":\"Mr. Anand Kedia\",\"phone\":\"753377049\"},{\"designation\":\"Secretary\",\"name\":\"Mr. Piyush Agarwal\",\"phone\":\"755140644\"},{\"designation\":\"Jt. Secretary\",\"name\":\"Mrs. Manisha Agarwal\",\"phone\":\"757603577\"},{\"designation\":\"Treasurer\",\"name\":\"Mr. Upendra Kumar Panday\"},{\"designation\":\"Jt. Treasurer\",\"name\":\"Mrs. Vandana Kundra\"},{\"designation\":\"Social Media Coordinator\",\"name\":\"Mrs. Ranjana Dubey\"},{\"designation\":\"Member\",\"name\":\"Mr. Amit Jain\"},{\"designation\":\"Member\",\"name\":\"Mrs. Alka Sharma\",\"phone\":\"\"},{\"designation\":\"Member\",\"name\":\"Mrs. Rashmi Sareen\",\"phone\":\"753997838\",\"email\":\"Sareen.roma5@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr. Gaurav Agarwal\",\"phone\":\"789511059\",\"email\":\"Gauravaggarwal29@gmail.com\"},{\"designation\":\"Member\",\"name\":\"Mr. Gulshan Ram\"},{\"name\":\"Mr. Ajay Kumar\"}]', 'north-indian-cultural-association-nica-2017-2019', '2018-05-26 15:57:24', '2018-05-26 15:57:24');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `field` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `name`, `description`, `value`, `field`, `active`, `created_at`, `updated_at`) VALUES
(1, 'contact_email', 'Contact form email address', 'The email address that all emails from the contact form will go to.', 'admin@updivision.com', '{\"name\":\"value\",\"label\":\"Value\",\"type\":\"email\"}', 1, NULL, NULL),
(2, 'phone_number', 'Phone number', 'Phone number of the association', '', '{\"name\":\"value\",\"label\":\"Value\",\"type\":\"text\"}', 1, NULL, NULL),
(3, 'about', 'about', 'About the company.', 'The Indian Association of Uganda is the apex body for 25,000 Indians/ persons of Indian origin living in Uganda and 34 community based associations. Established 90 years ago in 1922, it’s a charitable non-profit making body, registered NGO having its own constitution and incorporated under the trustees Incorporation Act (Cap. 165 of the Laws of Uganda), and is strongly geared towards promoting Social, Educational, Economic & cultural welfare of the people and residents of Uganda.', '{\"name\":\"value\",\"label\":\"Value\",\"type\":\"textarea\"}', 1, NULL, '2018-03-12 11:41:51'),
(4, 'mission', 'mission', 'Website mission', 'this is the value', '{\"name\":\"value\",\"label\":\"Value\", \"title\":\"Motto value\" ,\"type\":\"textarea\"}', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cta` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `title`, `cta`, `image`, `description`, `created_at`, `updated_at`) VALUES
(7, NULL, NULL, 'uploads/new/1.jpg', NULL, '2018-05-19 09:25:18', '2018-05-19 09:25:18'),
(8, NULL, NULL, 'uploads/new/2.jpg', NULL, '2018-05-19 09:25:26', '2018-05-19 09:25:26'),
(9, NULL, NULL, 'uploads/new/3.jpg', NULL, '2018-05-19 09:25:35', '2018-05-19 09:25:35'),
(10, NULL, NULL, 'uploads/new/4.jpg', NULL, '2018-05-19 09:25:43', '2018-05-19 09:25:43'),
(11, NULL, NULL, 'uploads/new/5.jpg', NULL, '2018-05-19 09:25:52', '2018-05-19 09:25:52');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`, `slug`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Sports', 'sports', '2018-05-26 21:58:12', '2018-05-26 22:01:18', NULL),
(2, 'Indian', 'indian', '2018-05-26 21:58:26', '2018-05-26 22:01:27', NULL),
(3, 'Bududa', 'bududa', '2018-05-26 22:00:55', '2018-05-26 22:00:55', NULL),
(4, 'Landslides', 'landslides', '2018-05-26 22:01:04', '2018-05-26 22:01:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`id`, `name`, `email`, `image`, `type`, `designation`, `description`, `created_at`, `updated_at`) VALUES
(20, 'Mr. Murtuza Dalal', NULL, 'uploads/team/Mr. Murtuza Dalal.png', 'trustie', 'Chairman- Board of Trustees', '<p align=\"justify\"><span style=\"font-size: small;\"><strong>PROFESSIONAL QUALIFICATION:</strong></span></p>\r\n<ul>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">Fellow Member &ndash; Institute of Chartered Accountants of India 1982</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">Full member &ndash; Institute of Certified Public Accountants of Uganda 1996</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">Full member &ndash; Institute of Certified Public Accountants of Kenya 2012</span></p>\r\n</li>\r\n</ul>\r\n<p align=\"justify\"><span style=\"font-size: small;\"><strong>OTHER VOLUNTARY SERVICE EXPERIENCE</strong></span></p>\r\n<ul>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">1996 to 2000 - Member, Education Committee, Institute of Certified Public Accountants&nbsp; of Uganda</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">2000 to 2003 &ndash; Member, Finance Committee, Institute of Certified Public Accountants of Uganda</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">2004 to date &ndash; Council Member, Institute of Certified Public Accountants of Uganda</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">2004 to date &ndash; Chairman, Finance Committee, Institute of Certified Public Accountants of Uganda</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">1997 to 2001 &ndash; Hon. Treasurer, Indian Association, Uganda</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">2002 to 2006 &ndash; Hon. Chairman &ndash; Executive Committee, Indian Association, Uganda</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">2002 to 2005 &ndash; Hon. Chairman &ndash; Giants Club of Kampala Central, Uganda</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">2010 to 2011 &ndash; Hon. Secretary, Indian Association, Uganda</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">2011 to 2016 &ndash; Trustee, Indian Association, Uganda</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">2016 onward &ndash; Chairperson, Board of Trustees of the Indian Association Uganda</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">2013 to 2015 &ndash; Member, Disciplinary and Ethics Committee, Institute of Certified Public Accountants of Uganda</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">2017 &ndash; onward &ndash; Chairperson of the Uganda (Kampala) Chapter of the Institute of Chartered Accountants of India</span></p>\r\n</li>\r\n</ul>\r\n<p align=\"justify\"><span style=\"font-size: small;\"><strong>Social:</strong></span></p>\r\n<ul>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">Organized the first ever Trade Delegation of Ugandan businessmen to India under the banner of The Indian Association, Uganda jointly with The Uganda Investment Authority in November 2002</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">Over the years have actively participated in cultural and social activities and charitable activities including blood donation camps, free medical camps, cultural programs to raise funds for charity etc in Uganda</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">Started the first ever quarterly newsletter &lsquo;Namaste&rsquo; of the Indian Association, Uganda in 2003. This newsletter helps to decimate information on Uganda</span> <span style=\"font-size: small;\">and India</span> <span style=\"font-size: small;\">to the residence of Uganda</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">Initiated and finalized the hosting of the Indian Association, Uganda website</span></p>\r\n</li>\r\n<li>\r\n<p align=\"justify\"><span style=\"font-size: small;\">Continue to assist the Indian Association Uganda (currently Chairperson, Board of Trustees) in their various charitable and social activities such as raising funds for charity, assisting in managing and advising in educational activities of the association, organizing social functions etc.</span></p>\r\n</li>\r\n</ul>', '2018-05-26 20:27:29', '2018-05-26 20:53:16'),
(21, 'Mr. Naren Mehta', NULL, 'uploads/team/Mr. Naren Mehta .png', 'trustie', 'Member - Board of Trustes', '<p>Mr. Naren Mehta came to Uganda in 1994; He holds Degree in Engineering and Masters in Marketing.</p>\r\n<p>He plays a pivotal role in Association&rsquo;s activities. He is member Board of Trustees, before that he was chairman (2006-2010) and vice chairman (2004-2006) of Indian Association . Chairman Board of Trustees - &nbsp;Indian Women Association and also Patron in North Indian Cultural Association</p>', '2018-05-26 20:52:37', '2018-05-26 20:52:37'),
(22, 'Mr. Rajesh Chaplot', NULL, 'uploads/team/Mr. Rajesh Chaplot.png', 'trustie', 'Member- Board of Trustees', '<p>Mr. Rajesh Chaplot is a Chartered Accountant by profession.</p>\r\n<p>He is a trustee of Indian Association and Indian Women Association. Chairman of a Committee in Presidential Investors\' Round Table(PIRT).&nbsp; Board Member of Miss Uganda Foundation. He was on the Board of Uganda Manufactures Association for 8 years. Rajesh is Managing Director of BPO Company &ldquo;CameoTechedge &ldquo;.</p>\r\n<p>General Manager of Graphic Systems (U) Ltd and Director of Fabrication Systems (U) Ltd, a Metal &amp; Aluminum Fabrication Company.&nbsp; Mr Chaplot is Founder Member of Rajasthani Association and he served as its Chairman also. Past Chairman of Indian Association. Past Trustee of Jain Samaj. &nbsp; Ex.&nbsp; Secretary General of Indian Business Forum.</p>', '2018-05-26 20:56:51', '2018-05-26 20:56:51'),
(23, 'Mr. Chacko Babu', NULL, 'uploads/team/Mr. Chacko Babu.png', 'trustie', 'Member- Board of Trustees', '<div>\r\n<div>Reached uganda in 1996. Masters in Chemistry.</div>\r\n<div>Working as G.M. of Kengrow Ind. Ltd. Serving as Chairman World Malayali Council,Africa region, Executive Director (jinja Investors Forum Ltd) and Chairman, board of governor\'s (St.Peter\'s High School jinja)</div>\r\n<div>&nbsp;</div>\r\n<div>Served as Vice Chairman and Chairman (Indian Association East North sector Jinja) and President of Lions Club of Jinja.</div>\r\n</div>\r\n<div>&nbsp;</div>', '2018-05-26 20:59:19', '2018-05-26 20:59:19'),
(24, 'Mr. Munnangi Sita. Ramanjaneya Reddy', NULL, 'uploads/team/Mr. Munnangi Sita. Ramanjaneya Reddy.png', 'trustie', 'Member- Board of Trustees', '<p><span style=\"font-size: 12.8px;\">Director - Balaji Group (E.A) Ltd</span></p>', '2018-05-26 21:01:25', '2018-05-26 21:01:25'),
(25, 'Mr.Nitin Vekariya', NULL, 'uploads/team/Mr.Nitin Vekariya .png', 'trustie', 'Member- Board of Trustees', '<p><span style=\"font-size: 12.8px;\">Veckson (U) Ltd</span></p>', '2018-05-26 21:04:27', '2018-05-26 21:04:27'),
(26, 'Mr. Hetal Parikh', NULL, 'uploads/team/Mr. Hetal Parikh.png', 'executive_committee', 'JOINT TREASURER', '<div>COORDINATOR&nbsp;</div>\r\n<div>IAU - MEDICAL , HEART SURGERY &amp; BLOOD DONATION PROJECTS&nbsp;</div>', '2018-05-26 21:17:16', '2018-05-26 21:17:16'),
(27, 'Mr. N.P Singh', NULL, 'uploads/team/Mr. N.P Singh.png', 'executive_committee', 'JOINT SECRETARY', '<div>Director- ORIENT POWER AFRICA LIMITED &nbsp; &nbsp; &nbsp; &nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div><strong>SOCIAL &nbsp;</strong> &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>{1} Secretary General : Sikh Association Uganda, &nbsp; &nbsp; &nbsp;&nbsp;</div>\r\n<div>{2} Vice Chairman : Ramgarhia Sikh Sports Club, &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</div>\r\n<div>{3} Member of United Religious Initiative of Africa and URI Great Lakes Region</div>', '2018-05-26 21:19:51', '2018-05-26 21:19:51'),
(28, 'Mr. Divyang Patel', NULL, 'uploads/team/Mr. Divyang Patel .png', 'executive_committee', 'Treasurer', NULL, '2018-05-26 21:20:42', '2018-05-26 21:20:42'),
(29, 'MR. MOHAMMED VAHEED', NULL, 'uploads/team/MR. MOHAMMED VAHEED.png', 'executive_committee', 'GENERAL SECRETARY', '<div>MANAGING DIRECTOR - SUN INDUSTRIES LTD</div>\r\n<div>DIRECTOR - METRO TYRES INTERNATIONAL LTD</div>\r\n<div>DIRECTOR - BUHINGA C&amp;F LTD</div>\r\n<div>MANAGING DIRECTOR - CRESTED CARGO INTERNATIONAL LTD</div>\r\n<div>&nbsp;</div>\r\n<div><strong>SPORTS&nbsp;</strong></div>\r\n<div>PATRON - UGANDA TABLE TENNIS ASSOCIATION</div>\r\n<div>VICE-CHAIRMAN (FINANCE COMMITTEE) - UGANDA BADMINTON ASSOCIATION</div>\r\n<div>CHAIRMAN - CHALLENGERS CRICKET CLUB</div>\r\n<div>DIRECTOR - M.K. BADMINTON ACADEMY&nbsp;</div>\r\n<div>DIRECTOR - ROLL TENNIS ACADEMY - MANDELA STADIUM</div>\r\n<div>FOUNDER - STRIKERS DEVELOPMENT CRICKET CLUB&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div><strong>SOCIAL&nbsp;</strong></div>\r\n<div>GENERAL SECRETARY - INDIAN ASSOCIATION UGANDA</div>\r\n<div>TRUSTEE - TAMIL SANGAM UGANDA</div>\r\n<div>CHAIRMAN- TMMK UGANDA</div>\r\n<div>GEN.SECRETARY - UGANDA SOCIAL EDUCATIONAL WELFARE ASSOCIATION&nbsp;</div>\r\n<div class=\"yj6qo ajU\">\r\n<div id=\":v3\" class=\"ajR\" tabindex=\"0\" data-tooltip=\"Show trimmed content\"><img class=\"ajT\" src=\"https://ssl.gstatic.com/ui/v1/icons/mail/images/cleardot.gif\" alt=\"\" /></div>\r\n</div>', '2018-05-26 21:22:37', '2018-05-26 21:22:37'),
(30, 'Mr. Trushar Upadhyay', NULL, 'uploads/team/Mr. Trushar Upadhyay.png', 'executive_committee', 'VICE - CHAIRMAN', '<p>Mr. Upadhyay is working with Graphic Systems Uganda Limited, he has 12 years of experience in printing industry, before working in the field of printing Trushar was working in Merchant Navy.</p>', '2018-05-26 21:24:48', '2018-05-26 21:24:48');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@admin.com', '$2y$10$vlWWgoJUJUMzZFCDQcbnae3AIaiRsKXZvFnKqvdYuYQQJGay4ZU8e', NULL, '2018-03-01 08:30:59', '2018-03-01 08:30:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `article_tag`
--
ALTER TABLE `article_tag`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Indexes for table `classifieds`
--
ALTER TABLE `classifieds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `classifieds_category_id_index` (`category_id`);

--
-- Indexes for table `classifieds_categories`
--
ALTER TABLE `classifieds_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `programs`
--
ALTER TABLE `programs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `regional`
--
ALTER TABLE `regional`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tags_slug_unique` (`slug`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `article_tag`
--
ALTER TABLE `article_tag`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `classifieds`
--
ALTER TABLE `classifieds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `classifieds_categories`
--
ALTER TABLE `classifieds_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `partners`
--
ALTER TABLE `partners`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `programs`
--
ALTER TABLE `programs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `regional`
--
ALTER TABLE `regional`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `classifieds`
--
ALTER TABLE `classifieds`
  ADD CONSTRAINT `classifieds_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `classifieds_categories` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
